// Export pages
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/result/result_widget.dart' show ResultWidget;
export '/auth1/auth1_widget.dart' show Auth1Widget;
export '/closest_recycling/closest_recycling_widget.dart'
    show ClosestRecyclingWidget;
export '/chat_bot/chat_bot_widget.dart' show ChatBotWidget;
export '/challenges/challenges_widget.dart' show ChallengesWidget;
export '/closest_recycling_copy/closest_recycling_copy_widget.dart'
    show ClosestRecyclingCopyWidget;
