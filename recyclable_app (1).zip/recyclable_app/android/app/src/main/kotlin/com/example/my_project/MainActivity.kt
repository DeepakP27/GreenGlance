package com.mycompany.recyclableapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
